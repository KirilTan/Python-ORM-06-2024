CREATE FUNCTION log10(numeric) RETURNS numeric
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN log((10)::numeric, $1);

COMMENT ON FUNCTION log10(numeric) IS 'base 10 logarithm';

ALTER FUNCTION log10(numeric) OWNER TO postgres;

