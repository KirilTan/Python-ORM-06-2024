CREATE FUNCTION age(timestamp without time zone) RETURNS interval
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN age((CURRENT_DATE)::timestamp without time zone, $1);

COMMENT ON FUNCTION age(timestamp) IS 'date difference from today preserving months and years';

ALTER FUNCTION age(timestamp) OWNER TO postgres;

