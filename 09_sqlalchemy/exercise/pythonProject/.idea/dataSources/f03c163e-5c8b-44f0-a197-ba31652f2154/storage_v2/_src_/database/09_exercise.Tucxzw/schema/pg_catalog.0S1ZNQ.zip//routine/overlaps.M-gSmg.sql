CREATE FUNCTION "overlaps"(timestamp with time zone, interval, timestamp with time zone, interval) RETURNS boolean
    STABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN (($1, ($1 + $2)) OVERLAPS ($3, ($3 + $4)));

COMMENT ON FUNCTION "overlaps"(timestamp WITH TIME ZONE, interval, timestamp WITH TIME ZONE, interval) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(timestamp WITH TIME ZONE, interval, timestamp WITH TIME ZONE, interval) OWNER TO postgres;

