CREATE FUNCTION quote_literal(anyelement) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select pg_catalog.quote_literal($1::pg_catalog.text)$$;

COMMENT ON FUNCTION quote_literal(anyelement) IS 'quote a data value for usage in a querystring';

ALTER FUNCTION quote_literal(anyelement) OWNER TO postgres;

