CREATE FUNCTION substring(text, text, text) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN "substring"($1, similar_to_escape($2, $3));

COMMENT ON FUNCTION substring(text, text, text) IS 'extract text matching SQL regular expression';

ALTER FUNCTION substring(text, text, text) OWNER TO postgres;

