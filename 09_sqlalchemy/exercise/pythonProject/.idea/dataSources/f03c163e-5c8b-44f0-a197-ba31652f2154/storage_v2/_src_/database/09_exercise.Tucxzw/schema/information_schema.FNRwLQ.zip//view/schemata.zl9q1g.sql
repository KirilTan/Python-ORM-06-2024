CREATE VIEW schemata
            (catalog_name, schema_name, schema_owner, default_character_set_catalog, default_character_set_schema,
             default_character_set_name, sql_path)
AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier      AS catalog_name,
       n.nspname::information_schema.sql_identifier               AS schema_name,
       u.rolname::information_schema.sql_identifier               AS schema_owner,
       NULL::name::information_schema.sql_identifier              AS default_character_set_catalog,
       NULL::name::information_schema.sql_identifier              AS default_character_set_schema,
       NULL::name::information_schema.sql_identifier              AS default_character_set_name,
       NULL::character varying::information_schema.character_data AS sql_path
FROM pg_namespace n,
     pg_authid u
WHERE n.nspowner = u.oid
  AND (PG_HAS_ROLE(n.nspowner, 'USAGE'::text) OR HAS_SCHEMA_PRIVILEGE(n.oid, 'CREATE, USAGE'::text));

ALTER TABLE schemata
    OWNER TO postgres;

GRANT SELECT ON schemata TO PUBLIC;

