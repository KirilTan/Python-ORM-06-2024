CREATE FUNCTION textanycat(text, anynonarray) RETURNS text
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
AS
$$select $1 operator(pg_catalog.||) $2::pg_catalog.text$$;

COMMENT ON FUNCTION textanycat(text, anynonarray) IS 'implementation of || operator';

ALTER FUNCTION textanycat(text, anynonarray) OWNER TO postgres;

