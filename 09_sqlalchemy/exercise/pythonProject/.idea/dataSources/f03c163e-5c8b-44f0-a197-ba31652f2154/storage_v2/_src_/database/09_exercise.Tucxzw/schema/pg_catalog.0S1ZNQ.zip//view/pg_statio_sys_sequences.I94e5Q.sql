CREATE VIEW pg_statio_sys_sequences(relid, schemaname, relname, blks_read, blks_hit) AS
SELECT relid,
       schemaname,
       relname,
       blks_read,
       blks_hit
FROM pg_statio_all_sequences
WHERE (schemaname = ANY (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
   OR schemaname ~ '^pg_toast'::text;

ALTER TABLE pg_statio_sys_sequences
    OWNER TO postgres;

GRANT SELECT ON pg_statio_sys_sequences TO PUBLIC;

