CREATE FUNCTION xpath(text, xml) RETURNS xml[]
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN xpath($1, $2, '{}'::text[]);

COMMENT ON FUNCTION xpath(text, xml) IS 'evaluate XPath expression';

ALTER FUNCTION xpath(text, xml) OWNER TO postgres;

