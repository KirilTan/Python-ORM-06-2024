CREATE FUNCTION interval_pl_timestamp(interval, timestamp without time zone) RETURNS timestamp without time zone
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN ($2 + $1);

COMMENT ON FUNCTION interval_pl_timestamp(interval, timestamp) IS 'implementation of + operator';

ALTER FUNCTION interval_pl_timestamp(interval, timestamp) OWNER TO postgres;

