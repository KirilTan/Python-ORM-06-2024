CREATE FUNCTION "overlaps"(timestamp without time zone, interval, timestamp without time zone, interval) RETURNS boolean
    IMMUTABLE
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN (($1, ($1 + $2)) OVERLAPS ($3, ($3 + $4)));

COMMENT ON FUNCTION "overlaps"(timestamp, interval, timestamp, interval) IS 'intervals overlap?';

ALTER FUNCTION "overlaps"(timestamp, interval, timestamp, interval) OWNER TO postgres;

