CREATE VIEW pg_hba_file_rules
            (rule_number, file_name, line_number, type, database, user_name, address, netmask, auth_method, options,
             error) AS
SELECT rule_number,
       file_name,
       line_number,
       type,
       database,
       user_name,
       address,
       netmask,
       auth_method,
       options,
       error
FROM pg_hba_file_rules() a(rule_number, file_name, line_number, type, database, user_name, address, netmask,
                           auth_method, options, error);

ALTER TABLE pg_hba_file_rules
    OWNER TO postgres;

