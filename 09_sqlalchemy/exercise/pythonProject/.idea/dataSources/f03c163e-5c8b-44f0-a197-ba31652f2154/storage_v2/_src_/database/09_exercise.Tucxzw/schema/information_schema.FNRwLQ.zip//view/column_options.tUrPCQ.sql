CREATE VIEW column_options (table_catalog, table_schema, table_name, column_name, option_name, option_value) AS
SELECT CURRENT_DATABASE()::information_schema.sql_identifier                                AS table_catalog,
       nspname::information_schema.sql_identifier                                           AS table_schema,
       relname::information_schema.sql_identifier                                           AS table_name,
       attname::information_schema.sql_identifier                                           AS column_name,
       (PG_OPTIONS_TO_TABLE(attfdwoptions)).option_name::information_schema.sql_identifier  AS option_name,
       (PG_OPTIONS_TO_TABLE(attfdwoptions)).option_value::information_schema.character_data AS option_value
FROM information_schema._pg_foreign_table_columns c;

ALTER TABLE column_options
    OWNER TO postgres;

GRANT SELECT ON column_options TO PUBLIC;

