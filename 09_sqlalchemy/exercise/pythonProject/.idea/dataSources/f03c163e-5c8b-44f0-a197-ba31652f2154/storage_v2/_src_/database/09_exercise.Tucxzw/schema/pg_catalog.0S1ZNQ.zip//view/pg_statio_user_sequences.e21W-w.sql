CREATE VIEW pg_statio_user_sequences(relid, schemaname, relname, blks_read, blks_hit) AS
SELECT relid,
       schemaname,
       relname,
       blks_read,
       blks_hit
FROM pg_statio_all_sequences
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND schemaname !~ '^pg_toast'::text;

ALTER TABLE pg_statio_user_sequences
    OWNER TO postgres;

GRANT SELECT ON pg_statio_user_sequences TO PUBLIC;

