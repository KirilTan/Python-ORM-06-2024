CREATE VIEW pg_statio_user_indexes
            (relid, indexrelid, schemaname, relname, indexrelname, idx_blks_read, idx_blks_hit) AS
SELECT relid,
       indexrelid,
       schemaname,
       relname,
       indexrelname,
       idx_blks_read,
       idx_blks_hit
FROM pg_statio_all_indexes
WHERE (schemaname <> ALL (ARRAY ['pg_catalog'::name, 'information_schema'::name]))
  AND schemaname !~ '^pg_toast'::text;

ALTER TABLE pg_statio_user_indexes
    OWNER TO postgres;

GRANT SELECT ON pg_statio_user_indexes TO PUBLIC;

