CREATE FUNCTION int8pl_inet(bigint, inet) RETURNS inet
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN ($2 + $1);

COMMENT ON FUNCTION int8pl_inet(bigint, inet) IS 'implementation of + operator';

ALTER FUNCTION int8pl_inet(bigint, inet) OWNER TO postgres;

