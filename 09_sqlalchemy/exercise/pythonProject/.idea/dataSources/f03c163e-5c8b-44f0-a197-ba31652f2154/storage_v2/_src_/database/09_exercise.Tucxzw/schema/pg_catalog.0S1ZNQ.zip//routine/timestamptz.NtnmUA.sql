CREATE FUNCTION timestamptz(date, time without time zone) RETURNS timestamp with time zone
    STABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN (($1 + $2))::timestamp with time zone;

COMMENT ON FUNCTION timestamptz(date, time) IS 'convert date and time to timestamp with time zone';

ALTER FUNCTION timestamptz(date, time) OWNER TO postgres;

