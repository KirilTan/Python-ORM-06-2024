CREATE FUNCTION bit_length(bit) RETURNS integer
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN length($1);

COMMENT ON FUNCTION bit_length(bit) IS 'length in bits';

ALTER FUNCTION bit_length(bit) OWNER TO postgres;

