CREATE VIEW pg_rules(schemaname, tablename, rulename, definition) AS
SELECT n.nspname             AS schemaname,
       c.relname             AS tablename,
       r.rulename,
       PG_GET_RULEDEF(r.oid) AS definition
FROM pg_rewrite r
         JOIN pg_class c ON c.oid = r.ev_class
         LEFT JOIN pg_namespace n ON n.oid = c.relnamespace
WHERE r.rulename <> '_RETURN'::name;

ALTER TABLE pg_rules
    OWNER TO postgres;

GRANT SELECT ON pg_rules TO PUBLIC;

