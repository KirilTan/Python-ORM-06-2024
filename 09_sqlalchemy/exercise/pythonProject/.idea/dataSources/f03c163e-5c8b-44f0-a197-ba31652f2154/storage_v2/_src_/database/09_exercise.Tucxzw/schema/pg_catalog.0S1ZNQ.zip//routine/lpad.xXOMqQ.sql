CREATE FUNCTION lpad(text, integer) RETURNS text
    IMMUTABLE
    STRICT
    PARALLEL SAFE
    COST 1
    LANGUAGE sql
RETURN lpad($1, $2, ' '::text);

COMMENT ON FUNCTION lpad(text, integer) IS 'left-pad string to length';

ALTER FUNCTION lpad(text, integer) OWNER TO postgres;

