CREATE VIEW pg_shmem_allocations(name, "off", size, allocated_size) AS
SELECT name,
        OFF,
        size,
        allocated_size
        FROM pg_get_shmem_allocations() pg_get_shmem_allocations(NAME, OFF, size, allocated_size);

ALTER TABLE pg_shmem_allocations
    OWNER TO postgres;

GRANT SELECT ON pg_shmem_allocations TO pg_read_all_stats;

